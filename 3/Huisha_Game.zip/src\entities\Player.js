export class Player {
    constructor(scene, x, y) {
        this.scene = scene;
        this.sprite = scene.physics.add.sprite(x, y, 'player_sheet', 0);
        this.sprite.setCollideWorldBounds(true);
        this.sprite.setPipeline('Light2D');
        
        this.initAnims();
        this.initFlashlight();
        
        this.speed = 150;
        this.lastStepTime = 0;
    }

    initAnims() {
        const anims = this.scene.anims;
        if (!anims.exists('walk-down')) {
            anims.create({
                key: 'walk-down',
                frames: [
                    { key: 'player_sheet', frame: 0 },
                    { key: 'player_sheet', frame: 1 },
                    { key: 'player_sheet', frame: 2 }
                ],
                frameRate: 10,
                repeat: -1
            });
            anims.create({
                key: 'walk-left',
                frames: [
                    { key: 'player_sheet', frame: 3 },
                    { key: 'player_sheet', frame: 4 },
                    { key: 'player_sheet', frame: 5 }
                ],
                frameRate: 10,
                repeat: -1
            });
            anims.create({
                key: 'walk-right',
                frames: [
                    { key: 'player_sheet', frame: 6 },
                    { key: 'player_sheet', frame: 7 },
                    { key: 'player_sheet', frame: 8 }
                ],
                frameRate: 10,
                repeat: -1
            });
            anims.create({
                key: 'walk-up',
                frames: [
                    { key: 'player_sheet', frame: 9 },
                    { key: 'player_sheet', frame: 10 },
                    { key: 'player_sheet', frame: 11 }
                ],
                frameRate: 10,
                repeat: -1
            });
        }
    }

    initFlashlight() {
        this.flashlight = this.scene.add.image(this.sprite.x, this.sprite.y, 'flashlight_cone');
        this.flashlight.setOrigin(0.5, 0);
        this.flashlight.setAlpha(0.6);
        this.flashlight.setBlendMode(Phaser.BlendModes.ADD);
        this.flashlight.setDepth(99);
        
        this.lightSource = this.scene.lights.addLight(this.sprite.x, this.sprite.y, 120).setIntensity(1.2);
    }

    update(cursors, wasd, joystick, soundManager) {
        this.sprite.setVelocity(0);

        let moveX = 0;
        let moveY = 0;

        // Keyboard Input
        if (cursors.left.isDown || wasd.left.isDown) moveX = -1;
        else if (cursors.right.isDown || wasd.right.isDown) moveX = 1;

        if (cursors.up.isDown || wasd.up.isDown) moveY = -1;
        else if (cursors.down.isDown || wasd.down.isDown) moveY = 1;

        // Joystick Input
        if (joystick.active) {
            if (Math.abs(joystick.x) > 0.1) moveX = joystick.x;
            if (Math.abs(joystick.y) > 0.1) moveY = joystick.y;
        }

        if (moveX !== 0 || moveY !== 0) {
            // Normalize
            if (!joystick.active && moveX !== 0 && moveY !== 0) {
                const len = Math.sqrt(moveX * moveX + moveY * moveY);
                moveX /= len;
                moveY /= len;
            }
            
            this.sprite.setVelocityX(moveX * this.speed);
            this.sprite.setVelocityY(moveY * this.speed);
            
            // Sound
            const now = this.scene.time.now;
            if (now - this.lastStepTime > 400) {
                soundManager.playNoise(0.08);
                if (Math.random() > 0.7) {
                    soundManager.playTone(100 + Math.random() * 50, 'sawtooth', 0.1);
                }
                this.lastStepTime = now;
            }
            
            // Anims
            if (Math.abs(moveX) > Math.abs(moveY)) {
                if (moveX > 0) this.sprite.anims.play('walk-right', true);
                else this.sprite.anims.play('walk-left', true);
            } else {
                if (moveY > 0) this.sprite.anims.play('walk-down', true);
                else this.sprite.anims.play('walk-up', true);
            }

            // Flashlight Rotation
            const targetAngle = Math.atan2(moveY, moveX) - Math.PI / 2;
            this.flashlight.rotation = Phaser.Math.Angle.RotateTo(this.flashlight.rotation, targetAngle, 0.15);
            
        } else {
            this.sprite.anims.stop();
        }

        // Sync Light Position
        this.flashlight.x = this.sprite.x;
        this.flashlight.y = this.sprite.y;
        this.lightSource.x = this.sprite.x;
        this.lightSource.y = this.sprite.y;
    }
}
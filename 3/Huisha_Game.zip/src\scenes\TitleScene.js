import { SoundManager } from '../systems/SoundManager.js';

export class TitleScene extends Phaser.Scene {
    constructor() {
        super('TitleScene');
    }

    create() {
        this.cameras.main.setBackgroundColor('#000000');
        
        // Init Sound
        this.input.keyboard.once('keydown', () => {
            if (!this.game.soundManager) {
                this.game.soundManager = new SoundManager(this);
            }
        });

        const titleText = this.add.text(400, 200, '回 煞', {
            fontFamily: '"SimSun", serif',
            fontSize: '80px',
            color: '#8b0000',
            fontStyle: 'bold'
        }).setOrigin(0.5);

        this.tweens.add({
            targets: titleText,
            alpha: 0.5,
            duration: 2000,
            yoyo: true,
            repeat: -1
        });

        const startText = this.add.text(400, 400, '按 [空格] 或 [点击屏幕] 开始', {
            fontFamily: '"SimSun", serif',
            fontSize: '24px',
            color: '#aaaaaa'
        }).setOrigin(0.5);

        const startGame = () => {
            if (!this.game.soundManager) {
                this.game.soundManager = new SoundManager(this);
            }
            this.game.soundManager.playTone(100, 'sawtooth', 2);
            this.cameras.main.fadeOut(1000, 0, 0, 0);
            this.cameras.main.once(Phaser.Cameras.Scene2D.Events.FADE_OUT_COMPLETE, () => {
                this.scene.start('GameScene');
            });
        };

        this.input.keyboard.once('keydown-SPACE', startGame);
        this.input.once('pointerdown', startGame);
    }
}
export class TextureGenerator {
    static generate(scene) {
        this.scene = scene;
        this.createPlayerSheet();
        this.createNpc();
        this.createEnvironment();
        this.createFlashlight();
        this.createVignette();
        this.createRain();
    }

    static createPlayerSheet() {
        const frameWidth = 32;
        const frameHeight = 48;
        const playerTexture = this.scene.make.graphics({ x: 0, y: 0, add: false });
        
        const drawPlayer = (x, y, dir, step) => {
            const hairColor = 0x1a1a1a;
            const skinColor = 0xe0c0a0;
            const clothesColor = 0x2c3e50;
            const pantsColor = 0x111111;
            
            // Body
            playerTexture.fillStyle(clothesColor);
            playerTexture.fillRect(x + 8, y + 16, 16, 18);
            
            // Legs
            playerTexture.fillStyle(pantsColor);
            let leftLegY = 0, rightLegY = 0;
            if (step === 1) { leftLegY = -2; rightLegY = 2; }
            if (step === 2) { leftLegY = 2; rightLegY = -2; }
            
            if (dir === 0 || dir === 3) {
                 playerTexture.fillRect(x + 10, y + 34 + leftLegY, 5, 12);
                 playerTexture.fillRect(x + 17, y + 34 + rightLegY, 5, 12);
            } else if (dir === 1) {
                if (step === 0) {
                    playerTexture.fillRect(x + 12, y + 34, 8, 12);
                } else if (step === 1) {
                    playerTexture.fillRect(x + 8, y + 32, 6, 12);
                    playerTexture.fillRect(x + 16, y + 34, 6, 10);
                } else {
                    playerTexture.fillRect(x + 16, y + 32, 6, 12);
                    playerTexture.fillRect(x + 8, y + 34, 6, 10);
                }
            } else if (dir === 2) {
                if (step === 0) {
                    playerTexture.fillRect(x + 12, y + 34, 8, 12);
                } else if (step === 1) {
                    playerTexture.fillRect(x + 16, y + 32, 6, 12);
                    playerTexture.fillRect(x + 8, y + 34, 6, 10);
                } else {
                    playerTexture.fillRect(x + 8, y + 32, 6, 12);
                    playerTexture.fillRect(x + 16, y + 34, 6, 10);
                }
            }

            // Head
            playerTexture.fillStyle(skinColor);
            playerTexture.fillRect(x + 9, y + 4, 14, 12);
            
            // Hair
            playerTexture.fillStyle(hairColor);
            if (dir === 3) {
                playerTexture.fillRect(x + 8, y + 2, 16, 14);
            } else {
                playerTexture.fillRect(x + 8, y + 2, 16, 6);
                if (dir === 1) playerTexture.fillRect(x + 20, y + 4, 4, 10);
                if (dir === 2) playerTexture.fillRect(x + 8, y + 4, 4, 10);
                if (dir === 0) {
                    playerTexture.fillRect(x + 8, y + 2, 4, 8);
                    playerTexture.fillRect(x + 20, y + 2, 4, 8);
                }
            }

            // Face
            if (dir !== 3) {
                 playerTexture.fillStyle(0x000000);
                 if (dir === 0) {
                     playerTexture.fillRect(x + 11, y + 10, 2, 2);
                     playerTexture.fillRect(x + 19, y + 10, 2, 2);
                 } else if (dir === 1) {
                     playerTexture.fillRect(x + 10, y + 10, 2, 2);
                 } else if (dir === 2) {
                     playerTexture.fillRect(x + 20, y + 10, 2, 2);
                 }
            }
        };

        for (let row = 0; row < 4; row++) {
            for (let col = 0; col < 3; col++) {
                drawPlayer(col * frameWidth, row * frameHeight, row, col);
            }
        }
        playerTexture.generateTexture('player_sheet', frameWidth * 3, frameHeight * 4);
    }

    static createNpc() {
        const npcGraphics = this.scene.make.graphics({ x: 0, y: 0, add: false });
        npcGraphics.fillStyle(0xffffff);
        npcGraphics.fillCircle(16, 16, 14);
        npcGraphics.fillStyle(0xffffff);
        npcGraphics.fillRect(8, 28, 16, 20);
        npcGraphics.fillStyle(0xff0000);
        npcGraphics.fillCircle(10, 18, 5);
        npcGraphics.fillCircle(22, 18, 5);
        npcGraphics.lineStyle(2, 0x000000);
        npcGraphics.strokeCircle(11, 14, 2);
        npcGraphics.strokeCircle(21, 14, 2);
        npcGraphics.lineStyle(2, 0xcc0000);
        npcGraphics.beginPath();
        npcGraphics.arc(16, 22, 6, 0.2, 2.94, false);
        npcGraphics.strokePath();
        npcGraphics.generateTexture('npc_paper', 32, 48);
    }

    static createEnvironment() {
        // Tile Floor
        const floorG = this.scene.make.graphics({x:0, y:0, add:false});
        floorG.fillStyle(0x3e2723);
        floorG.fillRect(0,0,32,32);
        floorG.lineStyle(1, 0x281a16);
        floorG.strokeRect(0,0,32,32);
        floorG.lineStyle(1, 0x4e342e, 0.5);
        floorG.beginPath();
        floorG.moveTo(4, 0); floorG.lineTo(4, 32);
        floorG.moveTo(18, 0); floorG.lineTo(18, 32);
        floorG.strokePath();
        floorG.generateTexture('tile_floor', 32, 32);

        // Wall
        const wallG = this.scene.make.graphics({x:0, y:0, add:false});
        wallG.fillStyle(0x555555);
        wallG.fillRect(0,0,32,32);
        wallG.fillStyle(0x333333);
        wallG.fillRect(0, 28, 32, 4);
        wallG.generateTexture('tile_wall', 32, 32);

        // Coffin
        const coffinG = this.scene.make.graphics({x:0, y:0, add:false});
        coffinG.fillStyle(0x0a0a0a);
        coffinG.fillRect(0, 0, 64, 128);
        coffinG.fillStyle(0x222222, 0.5);
        coffinG.fillRect(10, 0, 44, 128);
        coffinG.lineStyle(2, 0xd4af37);
        coffinG.strokeRect(4, 4, 56, 120);
        coffinG.fillStyle(0xd4af37);
        coffinG.fillCircle(32, 32, 12);
        coffinG.fillStyle(0x000000);
        coffinG.generateTexture('coffin', 64, 128);

        // Altar
        const altarG = this.scene.make.graphics({x:0, y:0, add:false});
        altarG.fillStyle(0x4e342e);
        altarG.fillRect(0, 0, 96, 48);
        altarG.fillStyle(0x8b0000);
        altarG.beginPath();
        altarG.moveTo(0, 0);
        altarG.lineTo(96, 0);
        altarG.lineTo(86, 30);
        altarG.lineTo(10, 30);
        altarG.closePath();
        altarG.fillPath();
        altarG.lineStyle(2, 0xd4af37);
        altarG.strokeRect(15, 5, 66, 20);
        altarG.generateTexture('altar', 96, 48);

        // Candle
        const candleG = this.scene.make.graphics({x:0, y:0, add:false});
        candleG.fillStyle(0xdddddd);
        candleG.fillRect(10, 10, 12, 22);
        candleG.fillStyle(0xff0000);
        candleG.fillRect(14, 14, 4, 4);
        candleG.fillStyle(0x222222);
        candleG.fillRect(15, 6, 2, 4);
        candleG.generateTexture('candle', 32, 32);

        // Rice
        const riceG = this.scene.make.graphics({x:0, y:0, add:false});
        riceG.fillStyle(0xffffff);
        riceG.beginPath();
        riceG.arc(16, 20, 10, Math.PI, 0);
        riceG.fillPath();
        riceG.fillStyle(0x336699);
        riceG.beginPath();
        riceG.arc(16, 20, 10, 0, Math.PI);
        riceG.fillPath();
        riceG.lineStyle(2, 0x000000);
        riceG.beginPath();
        riceG.moveTo(14, 5); riceG.lineTo(15, 20);
        riceG.moveTo(18, 5); riceG.lineTo(17, 20);
        riceG.strokePath();
        riceG.generateTexture('rice', 32, 32);
    }

    static createFlashlight() {
        const lightTexture = this.scene.textures.createCanvas('flashlight_cone', 200, 300);
        const ctx = lightTexture.getContext();
        
        const grd = ctx.createRadialGradient(100, 0, 0, 100, 0, 300);
        grd.addColorStop(0, 'rgba(255, 255, 220, 0.6)');
        grd.addColorStop(0.3, 'rgba(255, 255, 255, 0.2)');
        grd.addColorStop(1, 'rgba(255, 255, 255, 0)');
        ctx.fillStyle = grd;
        
        ctx.beginPath();
        ctx.moveTo(100, 0);
        ctx.lineTo(0, 300);
        ctx.quadraticCurveTo(100, 320, 200, 300); 
        ctx.lineTo(100, 0);
        ctx.fill();

        const coreGrd = ctx.createRadialGradient(100, 0, 0, 100, 0, 200);
        coreGrd.addColorStop(0, 'rgba(255, 255, 255, 0.4)');
        coreGrd.addColorStop(1, 'rgba(255, 255, 255, 0)');
        ctx.fillStyle = coreGrd;
        ctx.beginPath();
        ctx.moveTo(100, 0);
        ctx.lineTo(60, 200);
        ctx.quadraticCurveTo(100, 210, 140, 200);
        ctx.lineTo(100, 0);
        ctx.fill();
        
        lightTexture.refresh();
    }

    static createVignette() {
        const vignetteTexture = this.scene.textures.createCanvas('vignette', 800, 600);
        const vCtx = vignetteTexture.getContext();
        const vGrd = vCtx.createRadialGradient(400, 300, 300, 400, 300, 500);
        vGrd.addColorStop(0, 'rgba(0,0,0,0)');
        vGrd.addColorStop(1, 'rgba(0,0,0,0.9)');
        vCtx.fillStyle = vGrd;
        vCtx.fillRect(0, 0, 800, 600);
        vignetteTexture.refresh();
    }

    static createRain() {
        const rainG = this.scene.make.graphics({x:0, y:0, add:false});
        rainG.fillStyle(0xaaaaaa, 0.5);
        rainG.fillRect(0, 0, 2, 10);
        rainG.generateTexture('rain', 2, 10);
    }
}
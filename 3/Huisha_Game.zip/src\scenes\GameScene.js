import { Player } from '../entities/Player.js';

export class GameScene extends Phaser.Scene {
    constructor() {
        super('GameScene');
    }

    create() {
        this.soundManager = this.game.soundManager;
        this.gameState = {
            storyStep: 0,
            hasMatches: false,
            hasRice: false,
            candlesLit: 0,
            inventory: []
        };

        // Input
        this.cursors = this.input.keyboard.createCursorKeys();
        this.wasd = this.input.keyboard.addKeys({
            up: Phaser.Input.Keyboard.KeyCodes.W,
            down: Phaser.Input.Keyboard.KeyCodes.S,
            left: Phaser.Input.Keyboard.KeyCodes.A,
            right: Phaser.Input.Keyboard.KeyCodes.D
        });
        this.keyE = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.E);
        this.keySpace = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
        
        // Joystick Logic (Simple reference to DOM elements)
        this.joystick = { x: 0, y: 0, active: false };
        this.initJoystick();

        // Create World
        this.createMap();

        // Create Player
        this.player = new Player(this, 400, 500);
        this.physics.add.collider(this.player.sprite, this.walls);
        this.physics.add.collider(this.player.sprite, this.coffin);
        this.physics.add.collider(this.player.sprite, this.altar);

        // Camera
        this.cameras.main.startFollow(this.player.sprite);
        this.cameras.main.setZoom(1.2);

        // Lights & Atmosphere
        this.lights.enable();
        this.lights.setAmbientColor(0x222222);

        this.rainParticles = this.add.particles(0, 0, 'rain', {
            x: { min: 0, max: 800 },
            y: -10,
            quantity: 2,
            lifespan: 1000,
            speedY: { min: 400, max: 600 },
            speedX: { min: -20, max: 20 },
            scale: { start: 1, end: 1 },
            alpha: { start: 0.5, end: 0 },
            blendMode: 'ADD'
        });
        this.rainParticles.setDepth(200);
        this.rainParticles.setScrollFactor(0);

        this.vignette = this.add.image(400, 300, 'vignette');
        this.vignette.setScrollFactor(0);
        this.vignette.setDepth(300);
        this.vignette.setBlendMode(Phaser.BlendModes.MULTIPLY);

        // Ambience
        this.time.addEvent({
            delay: 100,
            callback: () => {
                 if (Math.random() > 0.5) this.soundManager.playNoise(0.05);
            },
            loop: true
        });

        // UI Text
        this.interactText = this.add.text(0, 0, '按 [空格] / [E] 调查', {
            fontSize: '16px',
            color: '#fff',
            backgroundColor: '#000'
        }).setOrigin(0.5).setVisible(false).setDepth(400);

        // Intro
        this.time.delayedCall(1000, () => {
            if (this.gameState.storyStep === 0) {
                window.showDialog('主角', '这雨越下越大...车子也抛锚了...', () => {
                     window.showDialog('主角', '前面好像有户人家，去借个宿吧。');
                });
            }
        });
    }

    createMap() {
        const mapData = [
            [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,1,1,1,0,0,1,1,1,0,0,0,0,0,0,0,1],
            [1,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1],
            [1,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
            [1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,1],
        ];

        this.floorLayer = [];
        this.walls = this.physics.add.staticGroup();

        for (let y = 0; y < mapData.length; y++) {
            for (let x = 0; x < mapData[y].length; x++) {
                const tile = this.add.image(x * 32 + 16, y * 32 + 16, 'tile_floor');
                tile.setPipeline('Light2D');
                this.floorLayer.push(tile);

                if (mapData[y][x] === 1) {
                    const wall = this.walls.create(x * 32 + 16, y * 32 + 16, 'tile_wall');
                    wall.setPipeline('Light2D');
                }
            }
        }

        this.coffin = this.physics.add.staticSprite(320, 150, 'coffin').setPipeline('Light2D');
        this.altar = this.physics.add.staticSprite(320, 250, 'altar').setPipeline('Light2D');
        this.leftCandle = this.add.sprite(290, 240, 'candle').setAlpha(0.3).setPipeline('Light2D');
        this.rightCandle = this.add.sprite(350, 240, 'candle').setAlpha(0.3).setPipeline('Light2D');
        this.dirtPile = this.physics.add.staticSprite(550, 350, 'tile_floor').setTint(0x555555).setPipeline('Light2D');
        this.stove = this.physics.add.staticSprite(100, 350, 'tile_wall').setTint(0x333333).setPipeline('Light2D');
        
        this.npc = this.physics.add.staticSprite(600, 400, 'npc_paper').setPipeline('Light2D');
    }

    update() {
        if (window.dialogActive) {
            this.player.sprite.setVelocity(0);
            return;
        }

        this.player.update(this.cursors, this.wasd, this.joystick, this.soundManager);
        this.checkInteraction();
    }

    checkInteraction() {
        let target = null;
        const px = this.player.sprite.x;
        const py = this.player.sprite.y;

        const distNpc = Phaser.Math.Distance.Between(px, py, this.npc.x, this.npc.y);
        if (distNpc < 50 && this.npc.visible) target = { type: 'npc', obj: this.npc };

        const distDirt = Phaser.Math.Distance.Between(px, py, this.dirtPile.x, this.dirtPile.y);
        if (distDirt < 50 && !this.gameState.hasRice) target = { type: 'dirt', obj: this.dirtPile };

        const distStove = Phaser.Math.Distance.Between(px, py, this.stove.x, this.stove.y);
        if (distStove < 50 && !this.gameState.hasMatches) target = { type: 'stove', obj: this.stove };

        const distAltar = Phaser.Math.Distance.Between(px, py, this.altar.x, this.altar.y);
        if (distAltar < 60) target = { type: 'altar', obj: this.altar };

        const distCoffin = Phaser.Math.Distance.Between(px, py, this.coffin.x, this.coffin.y);
        if (distCoffin < 60) target = { type: 'coffin', obj: this.coffin };

        if (target) {
            this.interactText.setPosition(px, py - 40).setVisible(true);
            this.currentTarget = target;
            
            if (Phaser.Input.Keyboard.JustDown(this.keyE) || Phaser.Input.Keyboard.JustDown(this.keySpace)) {
                this.handleInteraction();
            }
        } else {
            this.interactText.setVisible(false);
            this.currentTarget = null;
        }
    }

    handleInteraction() {
        if (!this.currentTarget) return;
        const { type } = this.currentTarget;

        if (type === 'npc') {
            if (this.gameState.storyStep === 0) {
                window.showDialog('奇怪的纸人', '嘻嘻...你也回来看奶奶了吗？', () => {
                    this.gameState.storyStep = 1;
                });
            } else {
                window.showDialog('奇怪的纸人', '奶奶饿了...奶奶怕黑...');
            }
        } else if (type === 'dirt') {
            window.showDialog('系统', '你在土堆里挖出了一碗插着筷子的饭...', () => {
                this.gameState.hasRice = true;
                window.updateInventory('死人饭');
                this.soundManager.playTone(400, 'triangle', 0.5);
                this.triggerPaperDollEvent();
            });
        } else if (type === 'stove') {
            window.showDialog('系统', '你在灶台缝隙里找到了一盒火柴。', () => {
                this.gameState.hasMatches = true;
                window.updateInventory('火柴');
                this.soundManager.playTone(400, 'triangle', 0.5);
                this.triggerPaperDollEvent();
            });
        } else if (type === 'altar') {
            if (this.gameState.hasRice && this.gameState.hasMatches) {
                window.showDialog('主角', '把这些东西放上去吧。', () => {
                    this.leftCandle.setAlpha(1);
                    this.rightCandle.setAlpha(1);
                    this.lights.addLight(this.leftCandle.x, this.leftCandle.y, 100).setColor(0xffaa00).setIntensity(1.5);
                    this.lights.addLight(this.rightCandle.x, this.rightCandle.y, 100).setColor(0xffaa00).setIntensity(1.5);
                    this.soundManager.playTone(600, 'sine', 1);
                    
                    window.showDialog('系统', '供桌上的蜡烛点燃了，那碗饭也摆好了。', () => {
                        this.time.delayedCall(500, () => {
                            this.cameras.main.shake(500, 0.02);
                            this.soundManager.playTone(100, 'sawtooth', 3);
                            window.showDialog('主角', '什么声音？！好像是从棺材里传出来的！');
                        });
                    });
                });
            } else {
                window.showDialog('主角', '供桌上少了一碗倒头饭，蜡烛也是熄灭的。');
            }
        } else if (type === 'coffin') {
            if (this.leftCandle.alpha === 1) {
                 window.showDialog('主角', '（颤抖着推开棺材盖...）', () => {
                     window.showDialog('主角', '这...这怎么可能！', () => {
                         this.add.text(400, 300, '棺材里躺着的\n竟然是你自己', { fontSize: '40px', color: '#ff0000', align: 'center' }).setOrigin(0.5).setScrollFactor(0);
                         this.cameras.main.fadeOut(3000);
                     });
                 });
            } else {
                window.showDialog('主角', '棺材盖钉得很死，打不开。');
            }
        }
    }

    triggerPaperDollEvent() {
        if ((this.gameState.hasRice && !this.gameState.hasMatches) || (!this.gameState.hasRice && this.gameState.hasMatches)) {
            this.cameras.main.flash(200, 255, 255, 255);
            this.soundManager.playTone(50, 'sawtooth', 1.5);
            this.npc.x = 320; 
            this.npc.y = 400;
            this.time.delayedCall(1000, () => {
                window.showDialog('主角', '刚才...是不是打雷了？那个纸人好像动了一下...');
            });
        } else if (this.gameState.hasRice && this.gameState.hasMatches) {
             this.cameras.main.flash(200, 255, 255, 255);
             this.soundManager.playTone(50, 'sawtooth', 1.5);
             this.npc.setVisible(false);
             this.npc.body.enable = false;
             this.time.delayedCall(1000, () => {
                window.showDialog('主角', '那个纸人不见了！');
             });
        }
    }

    initJoystick() {
        const zone = document.getElementById('joystick-zone');
        const knob = document.getElementById('joystick-knob');
        const actionBtn = document.getElementById('action-btn');
        
        let startX, startY;
        const maxDist = 35;
        let uiTimer = null;

        // Auto-hide UI Logic
        const showUI = () => {
            zone.classList.remove('ui-faded');
            actionBtn.classList.remove('ui-faded');
            if (uiTimer) clearTimeout(uiTimer);
        };

        const scheduleHideUI = () => {
            if (uiTimer) clearTimeout(uiTimer);
            uiTimer = setTimeout(() => {
                zone.classList.add('ui-faded');
                actionBtn.classList.add('ui-faded');
            }, 2000);
        };

        // Start hide timer initially
        scheduleHideUI();

        zone.addEventListener('touchstart', (e) => {
            showUI();
            e.preventDefault();
            const touch = e.touches[0];
            const rect = zone.getBoundingClientRect();
            startX = rect.left + rect.width / 2;
            startY = rect.top + rect.height / 2;
            this.joystick.active = true;
            this.updateJoystick(touch.clientX, touch.clientY, startX, startY, knob, maxDist);
        }, { passive: false });

        zone.addEventListener('touchmove', (e) => {
            showUI(); // Keep showing while moving
            e.preventDefault();
            if (!this.joystick.active) return;
            const touch = e.touches[0];
            this.updateJoystick(touch.clientX, touch.clientY, startX, startY, knob, maxDist);
        }, { passive: false });

        const endHandler = (e) => {
            scheduleHideUI(); // Start timer when let go
            this.joystick.active = false;
            this.joystick.x = 0;
            this.joystick.y = 0;
            knob.style.transform = `translate(-50%, -50%)`;
        };

        zone.addEventListener('touchend', endHandler);
        zone.addEventListener('touchcancel', endHandler);

        actionBtn.addEventListener('touchstart', (e) => {
            showUI();
            scheduleHideUI(); // Reset timer on click
            e.preventDefault();
            if (this.interactText.visible) {
                this.handleInteraction();
            }
        }, { passive: false });

        // Mouse click support for PC
        actionBtn.addEventListener('mousedown', (e) => {
            showUI();
            scheduleHideUI();
            e.preventDefault();
            if (this.interactText.visible) {
                this.handleInteraction();
            }
        });
    }

    updateJoystick(clientX, clientY, centerX, centerY, knob, maxDist) {
        let dx = clientX - centerX;
        let dy = clientY - centerY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > maxDist) {
            const ratio = maxDist / dist;
            dx *= ratio;
            dy *= ratio;
        }
        knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
        this.joystick.x = dx / maxDist;
        this.joystick.y = dy / maxDist;
    }
}